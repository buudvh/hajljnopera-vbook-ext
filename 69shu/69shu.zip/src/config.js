let BASE_URL = 'https://www.69shuba.com';
const STVHOST = "http://14.225.254.182";
const SHU69_HOST = "https://www.69shuba.com/"
const DEFAULT_COVER = "https://static.sangtacvietcdn.xyz/img/bookcover256.jpg";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}