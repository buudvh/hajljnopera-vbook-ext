//    var host = 'https://www.69shuba.com';
let BASE_URL = 'https://www.69shu.pro';
const STVHOST = "http://14.225.254.182";
const SHU69_HOST = "https://www.69shuba.com/"
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}