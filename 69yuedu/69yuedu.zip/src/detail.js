load('libs.js');
load('269shu.js');
function execute(url) {
    var data;
    data = getDetail69yuedu(url);
    return Response.success(data);

}