load('libs.js');
load('269shu.js');
load('crypto.js');
function execute(url) {
    var data;
    data = getToc69yuedu(url);
    return Response.success(data)
}