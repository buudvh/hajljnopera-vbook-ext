// let BASE_URL = 'https://www.69yuedu.net';
let BASE_URL = 'https://www.69shu.pro';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}