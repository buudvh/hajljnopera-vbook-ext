load('libs.js');
load('gbk.js');
function execute(url, page) {
    if (!page) page = '1';
    let inputUrl = url + '?page=' + page;
    let response = fetch(inputUrl);
    if (response.ok) {
        let doc = response.html('gbk');
        var data = [];
        var elems = $.QA(doc, 'article');
        if (!elems.length) return Response.error(url);
        elems.forEach(function(e) {
            data.push({
                name: bookData.book_name,
                link: $.QA(e, 'a').attr('href'),
                cover: $.QA(e, 'article > a > img').attr('src'),
                description: $.QA(e, 'article > div > div:nth-child(2)').text(),
                author: "",
                kind: ""
            })
        })
        let next_page = parseInt(page) + 1;
        return Response.success(data, next_page.toString());
    }
    return null;
}