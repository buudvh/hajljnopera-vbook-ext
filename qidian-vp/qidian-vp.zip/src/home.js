function execute() {
    var fxlist = [];

    fxlist.push({
        title: "Đề cử",
        input: "https://qidian-vp.com/xep-hang/de-cu",
        script: "gen.js"
    });

    return Response.success(fxlist);
}