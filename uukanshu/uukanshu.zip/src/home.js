function execute() {
    var fxlist = [
        {
            title: "完本小說",
            input: "https://uukanshu.cc/quanben/",
            script: "gen.js"
        }
    ];

    return Response.success(fxlist);
}